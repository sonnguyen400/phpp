<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php 
//Nguyễn HOàng Sơn 715105211
    // Bài tập 1
    echo "Bài tập 1<br>";
    $age=5;
    $price=100000;
    echo "Giá vé gốc $price vnđ<br>Tuổi: $age<br>";
    if($age<2) echo "Miễn phí";
    else if($age>=2&&$age<=6) echo "Giá vé giảm, 80% còn lại :".$price*0.2."vnđ";
    else if($age>60)  echo "Giá vé giảm 50%, còn lại:".$price*0.5."vnđ";
    else echo "Giá vé:$price";
    echo "<br>";
    
    // Bài tập 2
    echo "Bài tập 2<br>";
    $weight=70; //kg
    $height=1.8; //m
    $BMI=$weight/($height*$height);
    echo "weight: $weight    height: $height <br>  BMI:$BMI <br>";
    if($BMI<18.5) echo "Gầy - Nguy cơ phát triển bệnh thấp";
    elseif($BMI>=18.5&&$BMI<=24.9) echo "Bình thường - Nguy cơ phát triển bệnh trung bình";
    elseif($BMI>=25&&$BMI<=29.9) echo "Hơi béo - Nguy cơ phát triển bệnh cao";
    elseif($BMI>=30&&$BMI<=34.9) echo "Béo phì cấp độ 1 - Nguy cơ phát triển bệnh cao";
    elseif($BMI>=35&&$BMI<=39.9) echo "Béo phì cấp độ 2 - Nguy cơ phát triển bệnh: rất cao";
    else echo "Béo phì cấp độ 3 - Nguy cơ phát triển: nguy hiểm";
?>

</body>
</html>