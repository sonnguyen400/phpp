<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //Bài 3:  
        //1.
        $arr=array(
            'shirt'=>array(
                'sex'=>array(
                    0=>'male',
                    1=>'female'
                ),
                'color'=>array(
                    0=>'while',
                    1=>'blue',
                    2=>'black'
                ),
                'size'=>array(
                    0=>26,
                    1=>27,
                    2=>28
                ),
                'price'=>'80$'
            ),
            0=>'trouser',
            1=>'skirt',
            2=>'Tshirt',
            3=>'legging'
        );
        echo '<pre>';
        print_r($arr);
        echo '<pre>';
        //2.
        echo "shirt:", $arr['shirt']['price'],"<br>";
        //3.
        $arr['shirt']['price']='60$';
        echo '<pre>';
        print_r($arr);
        echo '<pre>';
    ?>
</body>
</html>