<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    function ptb1($a,$b){
        if($a==0) return "pt vô nghiệm";
         return "Nghiệm phương trình $a*x + $b=0 là :-$b/$a" ;
    }
    echo ptb1(5,8),'<br>';


    function ptb2($a,$b,$c){
        $delta = ($b * $b) - (4 * $a * $c);
        if($a==0) return "Phương trình không thòa mãn điều kiện a khác 0";
        if ($delta > 0) {
            $x1 = (-$b + sqrt($delta)) / (2 * $a);
            $x2 = (-$b - sqrt($delta)) / (2 * $a);
            return "Phương trình có hai nghiệm: x1 = $x1 và x2 = $x2";
        } elseif ($delta == 0) {
            $x = -$b / (2 * $a);
            return "Phương trình có nghiệm kép: x = $x";
        } else {
            return "Phương trình vô nghiệm ";
        }

    }
    echo ptb2(8,1,-5),'<br>';




    function giaithua($n){
        if($n==1) return 1;
        return $n*giaithua($n-1);
    }
    echo 'Giai thừa của 5: ', giaithua(5),'<br>';
    ?>
</body>
</html>