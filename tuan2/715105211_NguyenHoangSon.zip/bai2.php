<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table,tr,td{
            border: 1px solid black;
            border-collapse: collapse;
        }
        td{
            padding:5px;
        }
    </style>
</head>
<body>
    <?php 
    //Bài 2
    echo '<table>';
    for($i=1;$i<=6;$i++){
        echo '<tr>';
        for($j=1;$j<=5;$j++){
            echo "<td>$i*$j=",$i*$j,"</td>";
        }
        echo '</tr>';
    }
    echo '</table>';
    ?>
</body>
</html>